# MapVisualizator
Application for analysis of generated maps.
